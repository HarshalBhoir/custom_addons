# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

# python dependencies (either files or classes) are designated below 
# import <file_dependency>
# import <class_dependency>

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:

import acccess_right_wizard