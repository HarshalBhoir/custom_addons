# -*- coding: utf-8 -*-
##############################################################################
#
#	This module uses OpenERP, Open Source Management Solution Framework.
#	Copyright (C) 2014-Today BrowseInfo (<http://www.browseinfo.in>)
#
#	This program is free software: you can redistribute it and/or modify
#	it under the terms of the GNU General Public License as published by
#	the Free Software Foundation, either version 3 of the License, or
#	(at your option) any later version.
#
#	This program is distributed in the hope that it will be useful,
#	but WITHOUT ANY WARRANTY; without even the implied warranty of
#	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#	GNU General Public License for more details.
#
#	You should have received a copy of the GNU General Public License
#	along with this program.  If not, see <http://www.gnu.org/licenses/>
#
##############################################################################
from odoo.tools.translate import _
from datetime import datetime, timedelta, date
from dateutil.relativedelta import relativedelta
from odoo import tools, api
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT , DEFAULT_SERVER_DATETIME_FORMAT
from odoo import api, fields, models, _
import logging
from odoo.osv import  osv
from odoo import SUPERUSER_ID
from time import gmtime, strftime
from openerp.exceptions import UserError , ValidationError
import requests
import urllib
import simplejson
import dateutil.parser
import calendar
from odoo.addons import decimal_precision as dp


class hr_employee_category(models.Model):
	_name = "hr.employee.category"

	name  = fields.Char('Category')
	category_id  = fields.Char('Category ID')



class hr_extension(models.Model):
	_inherit = "hr.employee"

	# bp_code = fields.Char('Partner Code')
	grade_id = fields.Many2one("grade.master", string="Grade")
	c_bpartner_id = fields.Char('Idempiere ID')
	emp_id = fields.Char('Employee ID')
	date_of_joining = fields.Date("Date of Joining")
	date_of_resignation = fields.Date("Date of Resignation")
	last_date = fields.Date("Last Date Working")
	status = fields.Selection([
        ('present', 'Present'),
        ('transfer', 'Transfer'),
        ('left', 'Left')
        ], string='Status', copy=False, index=True, store=True)
	zone = fields.Selection([
        ('north', 'North'),
        ('east', 'East'),
        ('west', 'West'),
        ('south', 'South')
        ], string='Zone', copy=False, index=True, store=True)
	roll = fields.Selection([
        ('onroll', 'Onroll'),
        ('offroll', 'Offroll'),
        ('consultant', 'Consultant')
        ], string='Roll', copy=False, index=True, store=True)
	fnf = fields.Selection([
        ('na', 'NA'),
        ('pending', 'Pending'),
        ('processed', 'Processed')
        ], string='F & F', copy=False, index=True, store=True)
	category_ids = fields.Many2one("hr.employee.category", string="Category")
	category_id = fields.Char(string="Category ID" , related='category_ids.category_id')

	@api.model
	def get_ul(self, empl_id, date_from, date_to):
		# if date_to is None:
		# 	date_to = datetime.now().strftime('%Y-%m-%d')
		unpaid = self.env['hr.holidays.status'].search([('name','=','Unpaid')])
		# print "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
		self._cr.execute("SELECT sum(o.number_of_days) from hr_holidays as o where \
							 o.employee_id=%s \
							 AND to_char(o.date_from, 'YYYY-MM-DD') >= %s AND to_char(o.date_to, 'YYYY-MM-DD') <= %s ",
							(empl_id, date_from, date_to))
		res = self._cr.fetchall()

		# print "JJJJJJJJJJJJJJJJJJJJJJJJJJ" , res
		return res and res[0] or 0.0


	@api.model
	def get_leaves(self, empl_id, date_from, date_to, unpaid):
		self._cr.execute("SELECT sum(o.number_of_days) from hr_holidays as o where \
							 o.employee_id=%s \
							 AND to_char(o.date_from, 'YYYY-MM-DD') >= %s AND to_char(o.date_to, 'YYYY-MM-DD') <= %s AND o.holiday_status_id = %s",
							(empl_id, date_from, date_to, unpaid))
		res = self._cr.fetchone()

		return res and res[0] or 0.0


class hr_payslip(models.Model):
	_inherit = "hr.payslip"

	unpaid_id = fields.Many2one('hr.holidays.status', string="Status",  default=lambda self: self.env['hr.holidays.status'].search([('name', '=', 'Unpaid')], limit=1))
	month_days = fields.Integer(string="Days" , store=True, track_visibility='always')

	@api.onchange('date_from','date_to')
	def _default_days(self):
		if self.date_from and self.date_to:
			date_from = self.date_from
			date_to = self.date_to
			today = datetime.now()
			daymonthfrom = datetime.strptime(date_from, "%Y-%m-%d")
			daymonthto = datetime.strptime(date_to, "%Y-%m-%d")
			monthfrom = daymonthfrom.strftime("%m")
			monthto = daymonthto.strftime("%m")
			yearfrom = int(daymonthfrom.strftime("%Y"))
			yearto = daymonthto.strftime("%Y")

			monthfrom2 =  int(monthfrom[1:] if monthfrom.startswith('0') else monthfrom)
			monthto2 =  int(monthto[1:] if monthto.startswith('0') else monthto)

			if monthfrom2 == monthto2:
				self.month_days =  calendar.monthrange(yearfrom,monthfrom2)[1]


# 	# @api.multi
# 	# def compute_rule(self, localdict):
# 	# 	"""
# 	# 	:param localdict: dictionary containing the environement in which to compute the rule
# 	# 	:return: returns a tuple build as the base/amount computed, the quantity and the rate
# 	# 	:rtype: (float, float, float)
# 	# 	"""
# 	# 	self.ensure_one()
# 	# 	if self.amount_select == 'fix':
# 	# 		try:
# 	# 			return self.amount_fix, float(safe_eval(self.quantity, localdict)), 100.0
# 	# 		except:
# 	# 			raise UserError(_('Wrong quantity defined for salary rule %s (%s).') % (self.name, self.code))
# 	# 	elif self.amount_select == 'percentage':
# 	# 		try:
# 	# 			return (float(safe_eval(self.amount_percentage_base, localdict)),
# 	# 					float(safe_eval(self.quantity, localdict)),
# 	# 					self.amount_percentage)
# 	# 		except:
# 	# 			raise UserError(_('Wrong percentage base or quantity defined for salary rule %s (%s).') % (self.name, self.code))
# 	# 	else:
# 	# 		try:
# 	# 			safe_eval(self.amount_python_compute, localdict, mode='exec', nocopy=True)
# 	# 			return float(localdict['result']), 'result_qty' in localdict and localdict['result_qty'] or 1.0, 'result_rate' in localdict and localdict['result_rate'] or 100.0
# 	# 		except:
# 	# 			raise UserError(_('Wrong python code defined for salary rule %s (%s).') % (self.name, self.code))



# 	@api.model
# 	def get_payslip_lines(self, contract_ids, payslip_id):
# 		print "LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL"
# 		def _sum_salary_rule_category(localdict, category, amount):
# 			if category.parent_id:
# 				localdict = _sum_salary_rule_category(localdict, category.parent_id, amount)
# 			if category.code in localdict['categories'].dict:
# 				amount += localdict['categories'].dict[category.code]
# 			localdict['categories'].dict[category.code] = amount
# 			return localdict

# 		class BrowsableObject(object):
# 			def __init__(self, employee_id, dict, env):
# 				self.employee_id = employee_id
# 				self.dict = dict
# 				self.env = env

# 			def __getattr__(self, attr):
# 				return attr in self.dict and self.dict.__getitem__(attr) or 0.0

# 		class InputLine(BrowsableObject):
# 			"""a class that will be used into the python code, mainly for usability purposes"""
# 			def sum(self, code, from_date, to_date=None):
# 				if to_date is None:
# 					to_date = fields.Date.today()
# 				self.env.cr.execute("""
# 					SELECT sum(amount) as sum
# 					FROM hr_payslip as hp, hr_payslip_input as pi
# 					WHERE hp.employee_id = %s AND hp.state = 'done'
# 					AND hp.date_from >= %s AND hp.date_to <= %s AND hp.id = pi.payslip_id AND pi.code = %s""",
# 					(self.employee_id, from_date, to_date, code))
# 				return self.env.cr.fetchone()[0] or 0.0

# 		class WorkedDays(BrowsableObject):
# 			"""a class that will be used into the python code, mainly for usability purposes"""
# 			def _sum(self, code, from_date, to_date=None):
# 				if to_date is None:
# 					to_date = fields.Date.today()
# 				self.env.cr.execute("""
# 					SELECT sum(number_of_days) as number_of_days, sum(number_of_hours) as number_of_hours
# 					FROM hr_payslip as hp, hr_payslip_worked_days as pi
# 					WHERE hp.employee_id = %s AND hp.state = 'done'
# 					AND hp.date_from >= %s AND hp.date_to <= %s AND hp.id = pi.payslip_id AND pi.code = %s""",
# 					(self.employee_id, from_date, to_date, code))
# 				return self.env.cr.fetchone()

# 			def sum(self, code, from_date, to_date=None):
# 				res = self._sum(code, from_date, to_date)
# 				return res and res[0] or 0.0

# 			def sum_hours(self, code, from_date, to_date=None):
# 				res = self._sum(code, from_date, to_date)
# 				return res and res[1] or 0.0

# 		class Payslips(BrowsableObject):
# 			"""a class that will be used into the python code, mainly for usability purposes"""

# 			def sum(self, code, from_date, to_date=None):
# 				if to_date is None:
# 					to_date = fields.Date.today()
# 				self.env.cr.execute("""SELECT sum(case when hp.credit_note = False then (pl.total) else (-pl.total) end)
# 							FROM hr_payslip as hp, hr_payslip_line as pl
# 							WHERE hp.employee_id = %s AND hp.state = 'done'
# 							AND hp.date_from >= %s AND hp.date_to <= %s AND hp.id = pl.slip_id AND pl.code = %s""",
# 							(self.employee_id, from_date, to_date, code))
# 				res = self.env.cr.fetchone()
# 				return res and res[0] or 0.0

# 		#we keep a dict with the result because a value can be overwritten by another rule with the same code
# 		result_dict = {}
# 		rules_dict = {}
# 		worked_days_dict = {}
# 		inputs_dict = {}
# 		blacklist = []
# 		payslip = self.env['hr.payslip'].browse(payslip_id)
# 		for worked_days_line in payslip.worked_days_line_ids:
# 			worked_days_dict[worked_days_line.code] = worked_days_line
# 		for input_line in payslip.input_line_ids:
# 			inputs_dict[input_line.code] = input_line

# 		categories = BrowsableObject(payslip.employee_id.id, {}, self.env)
# 		inputs = InputLine(payslip.employee_id.id, inputs_dict, self.env)
# 		worked_days = WorkedDays(payslip.employee_id.id, worked_days_dict, self.env)
# 		payslips = Payslips(payslip.employee_id.id, payslip, self.env)
# 		rules = BrowsableObject(payslip.employee_id.id, rules_dict, self.env)

# 		baselocaldict = {'categories': categories, 'rules': rules, 'payslip': payslips, 'worked_days': worked_days, 'inputs': inputs}
# 		#get the ids of the structures on the contracts and their parent id as well
# 		contracts = self.env['hr.contract'].browse(contract_ids)
# 		structure_ids = contracts.get_all_structures()
# 		#get the rules of the structure and thier children
# 		rule_ids = self.env['hr.payroll.structure'].browse(structure_ids).get_all_rules()
# 		#run the rules by sequence
# 		sorted_rule_ids = [id for id, sequence in sorted(rule_ids, key=lambda x:x[1])]
# 		sorted_rules = self.env['hr.salary.rule'].browse(sorted_rule_ids)

# 		for contract in contracts:
# 			employee = contract.employee_id
# 			localdict = dict(baselocaldict, employee=employee, contract=contract)
# 			for rule in sorted_rules:
# 				key = rule.code + '-' + str(contract.id)

# 				localdict['result'] = None
# 				localdict['result_theoretical'] = None
# 				localdict['result_qty'] = 1.0
# 				localdict['result_rate'] = 100
# 				#check if the rule can be applied
# 				if rule.satisfy_condition(localdict) and rule.id not in blacklist:
# 					#compute the amount of the rule
# 					amount, qty, rate = rule.compute_rule(localdict)
# 					#check if there is already a rule computed with that code
# 					previous_amount = rule.code in localdict and localdict[rule.code] or 0.0
# 					#set/overwrite the amount computed for this rule in the localdict
# 					tot_rule = amount * qty * rate / 100.0
# 					localdict[rule.code] = tot_rule
# 					rules_dict[rule.code] = rule
# 					#sum the amount for its salary category
# 					localdict = _sum_salary_rule_category(localdict, rule.category_id, tot_rule - previous_amount)
# 					#create/overwrite the rule in the temporary results
# 					result_dict[key] = {
# 						'salary_rule_id': rule.id,
# 						'contract_id': contract.id,
# 						'name': rule.name,
# 						'code': rule.code,
# 						'category_id': rule.category_id.id,
# 						'sequence': rule.sequence,
# 						'appears_on_payslip': rule.appears_on_payslip,
# 						'condition_select': rule.condition_select,
# 						'condition_python': rule.condition_python,
# 						'condition_range': rule.condition_range,
# 						'condition_range_min': rule.condition_range_min,
# 						'condition_range_max': rule.condition_range_max,
# 						'amount_select': rule.amount_select,
# 						'amount_fix': rule.amount_fix,
# 						'amount_python_compute': rule.amount_python_compute,
# 						'theoretical_python_compute': rule.theoretical_python_compute,
# 						'amount_percentage': rule.amount_percentage,
# 						'amount_percentage_base': rule.amount_percentage_base,
# 						'register_id': rule.register_id.id,
# 						'amount': amount,
# 						'employee_id': contract.employee_id.id,
# 						'quantity': qty,
# 						'rate': rate,
# 					}
# 				else:
# 					#blacklist this rule and its children
# 					blacklist += [id for id, seq in rule._recursive_search_of_rules()]

# 		print "HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH" , result_dict
# 		return [value for code, value in result_dict.items()]


# 	@api.multi
# 	def compute_rule(self, localdict):
# 		"""
# 		:param localdict: dictionary containing the environement in which to compute the rule
# 		:return: returns a tuple build as the base/amount computed, the quantity and the rate
# 		:rtype: (float, float, float)
# 		"""
# 		self.ensure_one()
# 		if self.amount_select == 'fix':
# 			try:
# 				return self.amount_fix, float(safe_eval(self.quantity, localdict)), 100.0
# 			except:
# 				raise UserError(_('Wrong quantity defined for salary rule %s (%s).') % (self.name, self.code))
# 		elif self.amount_select == 'percentage':
# 			try:
# 				return (float(safe_eval(self.amount_percentage_base, localdict)),
# 						float(safe_eval(self.quantity, localdict)),
# 						self.amount_percentage)
# 			except:
# 				raise UserError(_('Wrong percentage base or quantity defined for salary rule %s (%s).') % (self.name, self.code))
# 		else:
# 			try:
# 				safe_eval(self.amount_python_compute, localdict, mode='exec', nocopy=True)
# 				safe_eval(self.theoretical_python_compute, localdict, mode='exec', nocopy=True)
# 				return float(localdict['result']), 'result_qty' in localdict and localdict['result_qty'] or 1.0, 'result_rate' in localdict and localdict['result_rate'] or 100.0
# 			except:
# 				raise UserError(_('Wrong python code defined for salary rule %s (%s).') % (self.name, self.code))

# 	@api.multi
# 	def satisfy_condition(self, localdict):
# 		"""
# 		@param contract_id: id of hr.contract to be tested
# 		@return: returns True if the given rule match the condition for the given contract. Return False otherwise.
# 		"""
# 		self.ensure_one()

# 		if self.condition_select == 'none':
# 			return True
# 		elif self.condition_select == 'range':
# 			try:
# 				result = safe_eval(self.condition_range, localdict)
# 				return self.condition_range_min <= result and result <= self.condition_range_max or False
# 			except:
# 				raise UserError(_('Wrong range condition defined for salary rule %s (%s).') % (self.name, self.code))
# 		else:  # python code
# 			try:
# 				safe_eval(self.condition_python, localdict, mode='exec', nocopy=True)
# 				return 'result' in localdict and localdict['result'] or False
# 			except:
# 				raise UserError(_('Wrong python condition defined for salary rule %s (%s).') % (self.name, self.code))



# # class hr_contract_extension(models.Model):
# # 	_inherit = "hr.contract"

# # 	theorotical value

# class hr_salary_rule_extension(models.Model):
# 	_inherit = 'hr.salary.rule'

# 	theoretical_python_compute = fields.Text(string='Theoretical Python Code',
# 		default='''
# 					# Available variables:
# 					#----------------------
# 					# payslip: object containing the payslips
# 					# employee: hr.employee object
# 					# contract: hr.contract object
# 					# rules: object containing the rules code (previously computed)
# 					# categories: object containing the computed salary rule categories (sum of amount of all rules belonging to that category).
# 					# worked_days: object containing the computed worked days.
# 					# inputs: object containing the computed inputs.

# 					# Note: returned value have to be set in the variable 'result'

# 					result = contract.wage * 0.10''')



# class hr_payslip_line_extension(models.Model):
# 	_inherit = 'hr.payslip.line'

# 	theoretical_amount = fields.Float(digits=dp.get_precision('Payroll'))



