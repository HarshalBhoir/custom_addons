Open ERP System :- Odoo 10 Community

Installation 
============
Install the Application => Apps -> Signup With Mobile Number(Technical Name:signup_with_phone)

Installation
============

To install this module, you need to have installed.

On Ubuntu::

  sudo pip install phonenumbers


Version
========
	Odoo v10

Module Configuration Guideline
=============================

	1. Sign up/ Registration form :
	   Settings -> General Settings -> Click on Allow external users to sign up -> Apply

