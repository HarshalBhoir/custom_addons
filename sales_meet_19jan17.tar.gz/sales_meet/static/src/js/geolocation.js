odoo.define('sales_meet.currentlatlong', function (require) {
    "use strict";

var core = require('web.core');
var Model = require('web.DataModel');
var QWeb = core.qweb;
var _t = core._t;

var options = {
  enableHighAccuracy: true,
  timeout: 5000,
  maximumAge: 0
};

console.log("LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL");


new Model("calendar.event").call("checkin", []).then(function(data) {
            console.log("Milallllllllllllllaaaaaaaaaaaaaaaaaaaa" + data);
        });
        
    // function success(pos) {
    //       var crd = pos.coords;

    //       console.log('Your current position is:');
    //       console.log(`Latitude : ${crd.latitude}`);
    //       console.log(`Longitude: ${crd.longitude}`);
    //       console.log(`More or less ${crd.accuracy} meters.`);
    //       console.log(self);
          
    //       var checkin_lattitude = crd.latitude;
    //       var checkin_longitude = crd.longitude;

    //       console.log('AAAAAAAAAAAAAA' + checkin_lattitude + checkin_longitude);

    //       my_object.checkin_lattitude = checkin_lattitude

    //        // self.view.fields.checkin_lattitude.set_value(checkin_lattitude);
    //         // this.field_manager.get_field_value('checkin_lattitude');

    //     };

    //     function error(err) {
    //       console.warn(`ERROR(${err.code}): ${err.message}`);
    //     };

    //     navigator.geolocation.getCurrentPosition(success, error, options);

});
        
